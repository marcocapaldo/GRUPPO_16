1) IMPORTARE IL DATABASE db.sql
2) Per effettuare correttamente il caricamento delle immagini del prodotto sbloccare i permessi all'intero path di cartelle fino a ./src/ del sito
3) ENJOY!!!

UTENTI DEL SITO

******************* Amministratori *********************

#user: admin  		#password: admin

******************* Venditori **************************

#user: Venditore 	#password: venditore

#user: Venditore2 	#password: venditore2

******************* Acquirenti *************************

#user: utente		#password: utente

#user: utente2		#password: utente2

#user: utente3		#password: utente3
