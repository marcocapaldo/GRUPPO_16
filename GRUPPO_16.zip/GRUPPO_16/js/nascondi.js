function nascondi(req, disp) {
    var x = document.getElementsByClassName("vend");
    for(var i=0; i<x.length;i++){
        x[i].required = req;
    }
    document.getElementById("venditore").style.display = disp;
}

function setDescription(select, description) {
    var option = document.getElementById(select.value);
    document.getElementById(description).value = option.getAttribute("data-descrizione");
}

function setValueRecensione(select) {//la classe è il venditore, l'id è l'identificativo della recensione
    var option = select.value;
    location.href="./pannelloAdmin.php?venditore="+option;
}

function setValueUtente(select) {
    var option = document.getElementById(select.value);
    
    if(option.getAttribute("data-vend") == 0){
        document.getElementById('radioVendNo').checked=true;
        document.getElementById('radioVendSi').checked=false;
    }
    else{
        document.getElementById('radioVendSi').checked=true;
        document.getElementById('radioVendNo').checked=false;
    }
    
    document.getElementById('removeE-mail').value = option.getAttribute("data-e_mail");
    document.getElementById('removeDesc').value = option.getAttribute("data-descrizione");
}

function checkRecensioni(){//controllo che almeno una recensione è selezionata prima del submit rimuoviRecensione
    var check=document.getElementsByName("removeIdRecensione[]");
    for(var i=0; i<check.length; i++){
        if(check[i].checked)
            return true;
    }
    
    alert("Selezionare una recensione, grazie");
    return false;
}