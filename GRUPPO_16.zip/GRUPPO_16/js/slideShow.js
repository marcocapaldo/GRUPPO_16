            var idInterval;
            var index = 0;
            slideShow();                                //inizializzo lo slide-show
            idInterval = setInterval(slideShow, 4000);  //imposto l'intervallo di esecuzione periodico dello slideshow
     /*     
            //associo le funzioni agli eventi per assegnarli a tutte le immagini
            var images=document.querySelectorAll(".slide");
            for (var i=0; i<images.length;i++){
                images[i].onmouseover=mouseEvent;
                images[i].onmouseout=mouseEvent;
            }
            function mouseEvent(e){//a seconda dell'evento fermo o faccio ripartire lo slideshow
                if(e.type=="mouseover" && e.target.getBoundingClientRect().left<300){
                        alert(e.target.offsetLeft);
                    clearInterval(idInterval);
                    e.target.style.animationPlayState = "paused";
                }
                else if(e.type=="mouseout"){
                    idInterval = setInterval(slideShow, 4000);
                }
            }*/
            
            function slideShow() { //funziona che cambia le immagini nello slideshow
                var x = document.querySelectorAll(".slide"); 
                for (var i = 0; i < x.length; i++) {
                   x[i].style.display = "none"; 
                }
                index++;
                if (index >= x.length) {
                    index = 0;
                }    
                x[index].style.display = "block";
                x[index].style.animationPlayState = "running";
            }