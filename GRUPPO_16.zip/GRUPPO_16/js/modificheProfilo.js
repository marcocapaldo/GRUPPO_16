//Questa funzione consente la modifica dei dati dell'utente nel form alla pressione del pulsante "Modifica dati"
function modifica() {
  var modifica = document.getElementById("datiUtente");
  var msg = "FAI ATTENZIONE!!!\n Stai per modificare i tuoi dati, se è stato uno sbaglio annulla la procedura";

  //modifica.disabled indica lo stato del fieldset. Se True, è disabilitato e in campi non sono modificabili
  if(modifica.disabled) {
    if (confirm(msg)) {
        document.getElementById("modifica").innerHTML = "Annulla"    //cambio il testo del tasto modifica in "Annulla"
        modifica.disabled = false;                                   //Abilito la modifica dei campi nel fieldset
        document.getElementById("invio").style.display="";          //mostro il pulsante per inviare la richiesta di modifica
    }
  }
  else {
    window.location.reload();   //se clicco su annulla aggiorno la pagina per garantire la correttezza dei dati(se modificavo i campi restavano modificati)
    }
}

//Questa funzione effettua un redirect alla pagina cambiaStatoProposta.php che effettua le query per accettare/rifiutare le proposte
function inviaRisposta(idProposta, codiceProdotto) {
  var idSelect = "stato"+idProposta; //mi occorre perchè quando stampo in php col while ho tutti tag select con id="statoID_proposta" con ID_Proposta = 1,2,...,N
  //select contiene l'indice (parte da 0) dell'opzione selezionata
  var select = document.getElementById(idSelect).options.selectedIndex;
  if(select == '0') {
    alert("Seleziona un opzione prima di inviare una risposta all'acquirente!");
  }
  else {
    if(select == '1')
      alert("Congratulazioni! Hai venduto il tuo prodotto, abbiamo informato l'acquirente a breve sarai ricontattato");
    window.location.href = './cambiaStatoProposta.php?idProposta=' + idProposta +'&codiceProdotto=' + codiceProdotto +'&select=' + select;
  }
}
