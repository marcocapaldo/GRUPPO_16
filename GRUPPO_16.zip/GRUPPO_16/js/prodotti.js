function checkSelectVenditore(name){
    document.getElementById('IDvenditore').value = name;
}

function resetta() {
    var x = document.getElementsByClassName("filtro");
    for(var i=0; i<=x.length;i++){
        x[i].value="";          //azzero il valore
    }
}

function checkRadioCategoria(radio){
    if(radio==""){
        radio = "tutte";
    }
    document.getElementById(radio).checked = true;
}

function checkSelectOrder(ordine){
    document.getElementById('IDordine').value = ordine;
}