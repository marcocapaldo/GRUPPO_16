<?php
session_start();

if(!isset($_SESSION['amministratore']) || $_SESSION['amministratore']==0){
    echo '<script type="text/javascript">
            alert("accedere come amministratore");
            location.href="../html/formAccedi.html";
          </script>';
}

require_once 'connect_DB.php';

$action=$_POST['action'];

if($action == 'modificaCategoria'){
    $query="UPDATE Categoria SET TitoloCategoria='".$_POST['newNameCategoria']."', DescrizioneCategoria='".$_POST['newDescriptionCategoria']."' 
            WHERE TitoloCategoria='".$_POST['oldNameCategoria']."'";
    $error="Inserire una categoria esistente";
}            
elseif($action == 'aggiungiCategoria'){
    $query="INSERT INTO Categoria(TitoloCategoria, DescrizioneCategoria) VALUE ('".$_POST['addNameCategoria']."','".$_POST['addDescriptionCategoria']."')";
    $error="La categoria da inserire è gia presente";
}
elseif($action == 'rimuoviCategoria'){
    $query="DELETE FROM Categoria WHERE TitoloCategoria='".$_POST['removeNameCategoria']."'";
    $error="La categoria inserita non è presente";
}
elseif($action == 'rimuoviRecensione'){//posso aver selezionato più recensioni
    if(!empty($_POST['removeIdRecensione'])){
        $length =  count($_POST['removeIdRecensione']);
        $concatena = "WHERE ID_Recensione='".$_POST['removeIdRecensione'][0]."'";
        for($i=1; $i<$length; $i++){
            $concatena = $concatena." OR ID_Recensione='".$_POST['removeIdRecensione'][$i]."'";
        }
        $query="DELETE FROM Recensione ".$concatena;
        $error="La recensione inserita non è presente";
    }
}
elseif($action == 'rimuoviUtente'){
    $query="DELETE FROM Utente WHERE Nickname='".$_POST['removeNickname']."'";
    $error="L'utente inserito non è presente";
}
else{
    echo"<script type='text/javascript'>
        alert('Operazione '$action' non riconosciuta, riprovare');
        window.location.href='./pannelloAdmin.php';
     </script>";
}

if(mysqli_query($connection, $query) == false){
    echo"<script type='text/javascript'>
        alert('ERRORE: $error');
        window.location.href='./pannelloAdmin.php';
     </script>";
}
else {
    echo"<script type='text/javascript'>
        alert('Aggiornamento effettuato con successo!');
        window.location.href='./pannelloAdmin.php?action=".$action."';
     </script>";
}

mysqli_close($connection);
?>
