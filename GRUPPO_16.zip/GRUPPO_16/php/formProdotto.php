<?php
session_start();
if(!isset($_SESSION['utente']))
    echo '<script type="text/javascript">
            alert("Per registrare un prodotto devi effettuare il login.");
            location.href="./formAccedi.php";
          </script>';

if($_SESSION['venditore'] == '0')
    echo '<script type="text/javascript">
            msg = "Non sei un venditore!\nDevi fornire ulteriori informazioni per poter vendere un prodotto: puoi aggiungerle nella sezione \"Modifica dati\" del tuo profilo.\n\nSe vuoi diventare venditore clicca su OK, in caso contrario sarai reindirizzato alla Home.";
            if(confirm(msg))
              location.href = "./profilo.php";
              else {
                location.href = "./listaProdotti.php";
              }
          </script>';
?>

<html>
  <head>
    <title>Aggiungi prodotto</title>
    <link rel="icon" href="../favicon.png">
    <meta name="application name" content="UniBay"/>
    <meta name="author" content="co-authored by Marco Capaldo, Emilio Rago, Andrea Murino">
    <meta name="description" content="Simply eCommerce site based on HTML5, CSS, PHP, JS">
    <meta name="keywords" content="ecommerce, buy, sell, sale, sconti, sconto, smartphone, elettronica">
    <link rel="stylesheet" type="text/css" href="../css/homeStyle.css">
    
    <script>  //  Questa funzione controlla che il titolo scelto dal venditore rispetti la specifica  
      function checkTitle(){
        var title = document.getElementById("titolo").value;
                  
                  // Il titolo deve iniziare con almeno 3 caratteri alfabetici
        var pattern = /^[a-zA-Z0-9]{3,30}$/g;          
                  
                  // se la condizione non è verificata restituisci il focus al title input
        if(!pattern.test(title)){         
          
          document.getElementById("titolo").focus();
          document.getElementById("titleError").innerHTML='Questo titolo non è consentito!';
          return false;
        
        }
        else{
          document.getElementById("titleError").innerHTML='';
          return true;
        }
      }
    </script>
  </head>

<body>
  <?php include "home.php"; ?>
	<fieldset>
    <legend><h1><code>Inserisci i dati del prodotto</code></h1></legend>
    <form  action="../php/registraProdotto.php" method="post" enctype="multipart/form-data" onsubmit="return checkTitle();">
        <table>
            <tr><td><label for="titolo" > Titolo </label></td>
                <td><input id="titolo" name="titolo" type="text" maxlength="30" onblur="checkTitle();" required/>
                  <span id="titleError" style="color:red; font-weight:bold"></span></td>
            </tr>
            <tr>
					<td><label for="categoria" >Categoria</label></td>
					<td>
					  <select name ="TitoloCategoria" required>
							<?php
                  require_once 'connect_DB.php';

                  $query = "SELECT TitoloCategoria FROM Categoria";
                  $rs = mysqli_query($connection, $query) or die("caricamento categorie fallito");

                  echo "<option value=''></option>";
                  while($riga = mysqli_fetch_row($rs)) {
                    echo "<option value='$riga[0]'>".$riga[0]."</option>";
                  }

                  mysqli_free_result($rs);
                  mysqli_close($connection);
               ?>
					  </select>
					</td>
				 </tr>
            <tr><td><label for="descr">Descrizione </label></td><td><textarea id="descr" name="descrizione" rows="5" cols="40" maxlength="255" minlength="10" required></textarea></td>
            </tr>
            <tr><td><label for="prezzo" > Prezzo minimo </label></td>
            <!-- Il prezzo minimo di proposta è 1 euro -->
				<td><input id="prezzo" name="prezzo" type="number" min=1 step="0.1" required/></td>
			</tr>
            <tr><td>Carica una foto</td>
                <td><input type="file" name="fotoProdotto[]" id="myfile" accept="image/*" multiple /></td>
            </tr>
            <tr><td><input type="submit" value="Pubblica" /> </td>
                <td><input type="Reset" value="Reset" /> </td>
            </tr>
        </table>
    </form>
    </fieldset>
</body>
</html>
