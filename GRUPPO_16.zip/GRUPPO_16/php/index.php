<html>
  <head>
    <title>Unibay: Sito online</title>
    <link rel="icon" href="../favicon.png">
    <link href="../css/homeStyle.css" rel="stylesheet" type="text/css">
    <link href="../css/slideShow.css" rel="stylesheet" type="text/css">
    
    <meta name="application name" content="UniBay"/>
    <meta name="author" content="co-authored by Marco Capaldo, Emilio Rago, Andrea Murino">
    <meta name="description" content="Simply eCommerce site based on HTML5, CSS, PHP, JS">
    <meta name="keywords" content="ecommerce, buy, sell, sale, sconti, sconto, smartphone, elettronica">
  </head>
  <body>
    <?php include './home.php'; ?>
    <br>
    <div class="slideShow">
      <img class="slide" src="../src/42.jpg">
      <img class="slide" src="../src/43.jpg">
      <img class="slide" src="../src/44.jpg">
    </div>
    
    <script type="text/javascript">
      var idInterval;
      var index = 0;
      slideShow();//inizializzo lo slide-show
      idInterval = setInterval(slideShow, 2000);//imposto l'intervallo di esecuzione dello slideshow
      
      //associo le funzioni agli eventi per assegnarli a tutte le immagini
      var images=document.getElementsByTagName("img");
      for (var i=0; i<images.length;i++){
          images[i].onmouseover=mouseEvent;
          images[i].onmouseout=mouseEvent;
      }
      
      function mouseEvent(e){//a seconda dell'evento fermo o faccio ripartire lo slideshow
          if(e.type=="mouseover")
              clearInterval(idInterval);
          else if(e.type=="mouseout")
              idInterval = setInterval(slideShow, 2000);
      }
      
      function slideShow() {
          var x = document.getElementsByClassName("slide");
          for (var i = 0; i < x.length; i++) {
             x[i].style.display = "none";  
          }
          index++;
          if (index >= x.length) {
              index = 0;
          }    
          x[index].style.display = "block";  
      }
    </script>
        
        
    </body>
</html>
  </body>
</html>
