<html lang="it">
    <head>
        <title>Profilo utente</title>
        <link rel="icon" href="../favicon.png">
        <meta name="application name" content="UniBay"/>
        <meta name="author" content="co-authored by Marco Capaldo, Emilio Rago, Andrea Murino">
        <meta name="description" content="Simply eCommerce site based on HTML5, CSS, PHP, JS">
        <meta name="keywords" content="ecommerce, buy, sell, sale, sconti, sconto, smartphone, elettronica">

        <link href="../css/profileStyle.css" rel="stylesheet" type="text/css">
        <link href="../css/homeStyle.css" rel="stylesheet" type="text/css">
        <script type="text/javascript" src="../js/nascondi.js"></script>
        <script type="text/javascript" src="../js/modificheProfilo.js"></script>
    </head>
    <body>
        <?php
        session_start();

        include 'home.php';
        require_once 'connect_DB.php';

        $nickname = $_SESSION['utente'];
        $isVenditore = $_SESSION['venditore'];

        $querydatiUtente = "SELECT * FROM Utente WHERE Nickname = '".$nickname."'";
        $queryproposteUtente = "SELECT * FROM Proposta WHERE Nickname = '".$nickname."'";
        $queryproposteRicevute = "SELECT * FROM Proposta WHERE CodiceProdotto IN (SELECT CodiceProdotto FROM Prodotto WHERE Nickname = '".$nickname."') AND StatoProposta = 'Inviata'";
        $querydettagliProdotto = "SELECT * FROM Prodotto WHERE CodiceProdotto = ";   //la completo quando stampo le recensioni utente
        $queryFaiRecensione = "SELECT DATEDIFF(DataAccettata, DataProposta) AS Giorni, ID_Proposta, ID_Recensione FROM Proposta WHERE StatoProposta = 'Accettata' AND Nickname = '".$nickname."'";
        $queryProdottiVenduti = "SELECT * FROM Prodotto WHERE Venduto = '1' AND Nickname = '".$nickname."' ORDER BY CodiceProdotto";
        $queryProdottiInVendita = "SELECT * FROM Prodotto WHERE Venduto = '0' AND Nickname = '".$nickname."' ORDER BY CodiceProdotto";
        $queryPrezzoVendita = "SELECT Prezzo FROM Proposta WHERE StatoProposta = 'Accettata' AND CodiceProdotto = ";   //la completo quando stampo i prodotti venduti

        $datiUtente = mysqli_fetch_array(mysqli_query($connection,$querydatiUtente));

        echo '<section>
                <h1><span>Ciao, </span>'.$nickname.'</h1>
                <p>In questa pagina troverai varie sezioni che ti consentiranno di tenere sott\'occhio il tuo profilo!</p><br>
              </section>';

        //stampa della sezione che visualizza i dati dell'utente e ne consente la modifica
        echo '<details style="margin:5pt">
                <summary>Dati personali</summary>
                  <fieldset disabled id="datiUtente" style="border:0px">
                    <form autocomplete="off" action="./modificaDati.php?azione=1" method="post">
                      <table>';

                  //per evitare che il venditore possa cambiare "tipo" di utente visualizzo la possibilità di diventare venditori solo agli utenti semplici
                  if($isVenditore != 1)
                    echo '<tr>
                            <td><label for="radio">Sei un venditore? </label></td>
                            <td><input id ="radio" type="radio" name="venditore" value="1" onclick="nascondi(true,\'\');"> Si </input>
                            <input id="radio" type="radio" name="venditore" value="0" checked="checked" onclick="nascondi(false,\'none\');"> No </input></td>
                          </tr>';
                  else {
                    echo '<input id="radio" type="radio" name="venditore" checked="checked" value="1" style="display:none"></input>';
                  }

                  echo '<tr>
                            <td><label for="e-mail">Email: </label></td>
                            <td><input type="email" id="e-mail" name="eMail" required value="'.$datiUtente['E_Mail'].'"></td>
                        </tr>
                        <tr>
                            <td><label for="descrizione">Descriviti: </label></td>
                            <td><textarea id="descrizione" name="descrizione" rows="5" cols="40" maxlength="255" required>'.$datiUtente['DescrizioneUtente'].'</textarea></td>
                        </tr>';

              //per il venditore la sezione contentente i dati personali deve esser visibile, per l'utente no
              if($isVenditore == 1)
                 echo '<tbody id="venditore">';
              else
                 echo '<tbody id="venditore" style="display:none">';

                    echo '<tr>
                              <td><label for="nome">Nome: </label></td>
                              <td><input type="text" class="vend" id="nome" name="nome" maxlength="30" value="'.$datiUtente['Nome'].'"></td>
                          </tr>
                          <tr>
                              <td><label for="cognome">Cognome: </label></td>
                              <td><input type="text" class="vend" id="cognome" name="cognome" maxlength="30" value="'.$datiUtente['Cognome'].'"></td>
                          </tr>
                          <tr>
                              <td><label for="dataNascita">Data di nascita: </label></td>
                              <td><input type="date" max="'.date("Y-m-d").'" class="vend" id="dataNascita" name="dataNascita" value="'.$datiUtente['DataNascita'].'"></td>
                          </tr>
                          <tr>
                              <td><label for="indirizzo">Indirizzo: </label></td>
                              <td><input type="text" class="vend" id="indirizzo" name="indirizzo" maxlength="50" value="'.$datiUtente['Indirizzo'].'"></td>
                          </tr>
                      </tbody>
                    </table>
                    <input type="submit" style="display:none; margin-top:5pt" id="invio" value="Invia dati"></input>
                  </form>
                </fieldset>
                  <button id="modifica" style="margin-left:10pt" onclick="modifica()">Modifica dati</button>
              </details>';
        ?>

        <!--stampa della sezione per reimpostare la password-->
        <details style="margin:15pt 5pt">
            <summary>Cambia password</summary>
            <form autocomplete="off" action="./modificaDati.php?azione=2" method="post">
                <table style="margin-top:10pt">
                    <tr>
                        <td><label for="oldpassword">Vecchia password: </label></td>
                        <td><input type="password" name="oldpassword" maxlength="30" required></td>
                    </tr>
                    <tr>
                        <td><label for="newpassword">Nuova password: </label></td>
                        <td><input type="password" name="newpassword" maxlength="30" required></td>
                    </tr>
                    <tr>
                        <td><label for="repassword">Ripeti password: </label></td>
                        <td><input type="password" name="repassword" maxlength="30" required></td>
                    </tr>
                </table>
                <input type="submit" style="margin-top:10pt" value="Modifica password">
              </form>
        </details>

        <?php
        //stampa delle sezione delle proposte effettuate dall'Utente
        echo '<details style="margin:15pt 5pt 15pt">
                  <summary>Proposte inviate</summary>';

              $rsProposta = mysqli_query($connection, $queryproposteUtente);
              $rsRecensione = mysqli_query($connection, $queryFaiRecensione);
              if(mysqli_num_rows($rsProposta) != 0)
                while($proposteUtente = mysqli_fetch_array($rsProposta)) {
                  //per ogni proposta reperisco i dettagli del prodotto
                  $infoProdotto = mysqli_fetch_array(mysqli_query($connection, $querydettagliProdotto.$proposteUtente['CodiceProdotto']));

                  //controllo le cifre decimali degli importi di prezzo e prodotto per mostrare un formato del prezzo sempre del tipo €xxx.yy
                  $digitalDigitProdotto = strlen(substr(strrchr($infoProdotto['PrezzoMinimo'], "."), 1));
                  $digitalDigitProdotto = ($digitalDigitProdotto == 0) ? ".00":"0";
                  $digitalDigitProposta = strlen(substr(strrchr($proposteUtente['Prezzo'], "."), 1));
                  $digitalDigitProposta = ($digitalDigitProposta == 0) ? ".00":"0";

                  echo '<section>
                          <a href="./prodotto.php?codiceProdotto='.$infoProdotto['CodiceProdotto'].'">'.$infoProdotto['Titolo'].'</a>
                          <p style="display:inline"> ['.$infoProdotto['TitoloCategoria'].'] </p>
                          <table style="display:inline">
                            <tr>
                              <td>Prezzo richiesto</td>
                              <td>Prezzo proposta</td>
                            </tr>
                            <tr>
                              <td>€'.$infoProdotto['PrezzoMinimo'].$digitalDigitProdotto.'</td>
                              <td>€'.$proposteUtente['Prezzo'].$digitalDigitProposta.'</td>
                            </tr>
                          </table>';
                          switch($proposteUtente['StatoProposta']) {
                            case 'Accettata':
                              echo '<p>Stato proposta: <strong style="color:green">Accettata</strong><p>';

                              //se la proposta è accettata devo poter effettuare una recensione (se non superati i 10gg)
                              $recensione = mysqli_fetch_array($rsRecensione);
                              if ($recensione['ID_Recensione'] == "") {
                                if(intval($recensione['Giorni']) < 10)
                                  echo '<a href="./formRecensione.php?idProposta='.$recensione['ID_Proposta'].'">Effettua una recensione!</a>';
                                else
                                  echo "Tempo scaduto per effettuare una recensione.";
                              }
                              else
                                echo "Hai già effettuato una recensione per questo prodotto!";
                              break;

                            case 'Inviata':
                                echo '<p>Stato proposta: <strong style="color:black">Inviata</strong><p>';
                                break;

                            case 'Rifiutata':
                              echo '<p>Stato proposta: <strong style="color:red">Rifiutata</strong><p>';
                              if($infoProdotto['Venduto'] == 1)
                                echo '<p>Ci dispiace, questo prodotto è stato già venduto.</p>';
                                else {
                              echo '<p>Ops! Il venditore ha rifiutato la tua proposta. Effettuane una nuova
                                    <a href="./prodotto.php?codiceProdotto='.$infoProdotto['CodiceProdotto'].'">QUI</a>
                                  </p>';
                                }

                              break;
                          }
                  echo '</section><hr>';
                }
              else {
                echo "<section>
                        <p>Non hai inviato ancora nessuna proposta. Dai un'occhiata ai nostri
                          <a href='./listaProdotti.php'>prodotti</a>
                        </p>
                      </section>";
              }
        echo '</details>';

      //se l'utente è un venditore stampo anche le proposte che ha ricevuto e gli articoli che ha venduto
      if($isVenditore == 1) {
        echo '<details style="margin:15pt 5pt" >
                  <summary>Proposte ricevute</summary>';

              //stampa della sezione venditore con il riepilogo delle proposte ricevute
              $rsProposteRivevute = mysqli_query($connection, $queryproposteRicevute);
              if(mysqli_num_rows($rsProposteRivevute) != 0) {
                while($proposteRicevute = mysqli_fetch_array($rsProposteRivevute)) {

                  $infoProdotto = mysqli_fetch_array(mysqli_query($connection, $querydettagliProdotto.$proposteRicevute['CodiceProdotto']));

                  //controllo le cifre decimali degli importi di prezzo e prodotto per mostrare un formato del prezzo sempre del tipo €xxx.yy
                  $digitalDigitProdotto = strlen(substr(strrchr($infoProdotto['PrezzoMinimo'], "."), 1));
                  $digitalDigitProdotto = ($digitalDigitProdotto == 0) ? ".00":"0";
                  $digitalDigitProposta = strlen(substr(strrchr($proposteRicevute['Prezzo'], "."), 1));
                  $digitalDigitProposta = ($digitalDigitProposta == 0) ? ".00":"0";

                  echo '<section>
                          <a href="./prodotto.php?codiceProdotto='.$infoProdotto['CodiceProdotto'].'">'.$infoProdotto['Titolo'].'</a>
                          <p style="display:inline"> ['.$infoProdotto['TitoloCategoria'].'] </p>
                          <table style="display:inline">
                            <tr>
                              <td>Prezzo richiesto</td>
                              <td>Prezzo proposta</td>
                            </tr>
                            <tr>
                              <td>€'.$infoProdotto['PrezzoMinimo'].$digitalDigitProdotto.'</td>
                              <td>€'.$proposteRicevute['Prezzo'].$digitalDigitProposta.'</td>
                            </tr>
                          </table>
                          <select id="stato'.$proposteRicevute['ID_Proposta'].'">
                            <option value="-">-</option>
                            <option value="accetta">Accetta</option>
                            <option value="rifiuta">Rifiuta</option>
                          </select>
                          <button onclick="inviaRisposta(\''.$proposteRicevute['ID_Proposta'].'\',\''.$infoProdotto['CodiceProdotto'].'\')">Invia risposta</button>
                        </section><hr>';
                }
              }
              else {
                echo "<section>
                        <p>Nessuna proposta in sospeso per i tuoi articoli.</p>
                      </section>";
              }
      echo '</details>';

      //stampa della sezione venditore con il riepilogo degli oggetti venduti
      echo '<details style="margin:15pt 5pt 15pt">
                <summary>Riepilogo prodotti venduti</summary>';

            $rsProdottiVenduti = mysqli_query($connection, $queryProdottiVenduti);
            if(mysqli_num_rows($rsProdottiVenduti) != 0) {
              while($prodottiVenduti = mysqli_fetch_array($rsProdottiVenduti)) {
                $prezzoVendita = mysqli_fetch_array(mysqli_query($connection, $queryPrezzoVendita."'".$prodottiVenduti['CodiceProdotto']."' ORDER BY CodiceProdotto"));

                //controllo le cifre decimali degli importi di prezzo e prodotto per mostrare un formato del prezzo sempre del tipo €xxx.yy
                $digitalDigitProdotto = strlen(substr(strrchr($prodottiVenduti['PrezzoMinimo'], "."), 1));
                $digitalDigitProdotto = ($digitalDigitProdotto == 0) ? ".00":"0";
                $digitalDigitVenduto = strlen(substr(strrchr($prezzoVendita['Prezzo'], "."), 1));
                $digitalDigitVenduto = ($digitalDigitVenduto == 0) ? ".00":"0";

                echo '<section>
                        <a href="./prodotto.php?codiceProdotto='.$prodottiVenduti['CodiceProdotto'].'">'.$prodottiVenduti['Titolo'].'</a>
                        <p style="display:inline"> ['.$prodottiVenduti['TitoloCategoria'].'] </p>
                        <table style="display:inline">
                          <tr>
                            <td>Prezzo richiesto</td>
                            <td>Prezzo vendita</td>
                          </tr>
                          <tr>
                            <td>'.$prodottiVenduti['PrezzoMinimo'].$digitalDigitProdotto.'</td>
                            <td>'.$prezzoVendita['Prezzo'].$digitalDigitVenduto.'</td>
                          </tr>
                        </table>
                      </section><hr>';
              }
            }
            else {
              echo "<section>
                      <p>Non hai ancora venduto un articolo. Non temere continua a pubblicare oggetti!</p>
                    </section>";
            }
        echo '</details>';


            //stampa della sezione che mostra e consente la cancellazione dei prodotti in vendita
      echo '<details style="margin:15pt 5pt 15pt">
                <summary>Prodotti in vendita</summary>';

            $rsprodottiInVendita = mysqli_query($connection, $queryProdottiInVendita);
            if(mysqli_num_rows($rsprodottiInVendita) != 0) {
              while($prodottiInVendita = mysqli_fetch_array($rsprodottiInVendita)) {

                //controllo le cifre decimali degli importi di prezzo e prodotto per mostrare un formato del prezzo sempre del tipo €xxx.yy
                $digitalDigitProdotto = strlen(substr(strrchr($prodottiInVendita['PrezzoMinimo'], "."), 1));
                $digitalDigitProdotto = ($digitalDigitProdotto == 0) ? ".00":"0";

                echo '<section>
                        <a href="./prodotto.php?codiceProdotto='.$prodottiInVendita['CodiceProdotto'].'">'.$prodottiInVendita['Titolo'].'</a>
                        <p style="display:inline"> ['.$prodottiInVendita['TitoloCategoria'].'] </p>
                        <table style="display:inline">
                          <tr>
                            <td>Prezzo richiesto</td>
                            <td><a href="./eliminaProdotto.php?codiceProdotto='.$prodottiInVendita['CodiceProdotto'].'"><img src="../src/delete.png" width="25pt" height="25pt"></a></td>
                          </tr>
                          <tr>
                            <td>€'.$prodottiInVendita['PrezzoMinimo'].$digitalDigitProdotto.'</td>
                          <tr>
                        </table>
                      </section><hr>';
              }
            }
            else {
              echo "<section>
                      <p>Attualmente non hai nessun articolo in vendita.</p>
                    </section>";
            }
          echo '</details>';
        }
        ?>
    </body>
</html>
