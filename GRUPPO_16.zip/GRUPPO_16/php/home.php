<header>
      <div class="topDiv">
        <a href="../php/index.php"><img src="../src/home.png" height="20pt" width="20ptpt">&nbsp;HOME</a>
        <a href="../php/listaProdotti.php"><img src="../src/product.png" height="20pt" width="20pt">&nbsp;Prodotti</a>
        <a href="../php/contatti.php"><img src="../src/contact.png" height="20pt" width="20pt">&nbsp;Contatti</a>
        <?php session_start();
        
        if(!empty($_SESSION['utente'])){
           echo '<a href="../php/profilo.php" style="float:right"><img src="../src/profilo.png" height="20pt" width="20pt">&nbsp;Profilo</a>
                 <a href="./listaProdotti.php?logout=1" style="float:right"><img src="../src/logout.png" height="20pt" width="20pt">&nbsp;Logout</a>';
        }
        else {
           echo '<a href="../php/formAccedi.php" style="float:right"><img src="../src/login.png" height="20pt" width="20pt">&nbsp;Login</a>
                 <a href="../php/formRegistra.php" style="float:right"><img src="../src/register.png" height="20pt" width="20pt">&nbsp;Registrati</a>'; 
        }
        
        if(!empty($_SESSION['venditore']) && $_SESSION['venditore']==1){
           echo '<a href="./formProdotto.php" style="float:right"><img src="../src/publish.png" height="20pt" width="20pt">&nbsp;Inserisci annuncio</a>';
        }
        
        if(!empty($_SESSION['amministratore']) && $_SESSION['amministratore']==1){
           echo '<a href="./pannelloAdmin.php" style="float:right"><img src="../src/admin.png" height="20pt" width="20pt">&nbsp;Pannello Admin</a>';
        }
        ?>
      </div>
      
      <div class="middleDiv">
        <a href="../php/listaProdotti.php"><img src="../src/logo.png" width="300pt" height="100pt" style="margin:10pt"></a>
        <section id="mDsearch" style="display: table">
          <div style="display: table-row">
            <form action="../php/listaProdotti.php" method="get">
              <input type="search" name="cercaTitolo">
              <button id="search" title="Cerca" type="submit"><img src="../src/search.png" height="40" width="40"/></button>
            </form>
          </div>
        </section>
      </div>
</header>
