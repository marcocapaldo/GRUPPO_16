<?php
session_start();

if(empty($_SESSION['utente'])) {
  header('Location: form.php');
  exit();
}

require_once 'connect_DB.php';

$queryProdotto = "SELECT Titolo, Nickname FROM Prodotto WHERE CodiceProdotto = (SELECT CodiceProdotto FROM Proposta WHERE ID_Proposta = '".$_GET['idProposta']."')";
$prodotto = mysqli_fetch_array(mysqli_query($connection, $queryProdotto));
?>

<!DOCTYPE html5>
<html lang="it">
    <head>
        <title>Fai una recensione</title>
        <meta name="application name" content="UniBay"/>
        <meta name="author" content="co-authored by Marco Capaldo, Emilio Rago, Andrea Murino">
        <meta name="description" content="Simply eCommerce site based on HTML5, CSS, PHP, JS">
        <meta name="keywords" content="ecommerce, buy, sell, sale, sconti, sconto, smartphone, elettronica">
        <link href="../css/formStyle.css" rel="stylesheet" type="text/css">
        <link href="../css/homeStyle.css" rel="stylesheet" type="text/css">
    </head>

    <body>
        <?php include 'home.php'; ?>
        <fieldset>
          <legend>Inserisci la recensione</legend>
          <form  autocomplete="off" action="../php/recensione.php?idProposta=<?php echo $_GET['idProposta']; ?>" method="post">
        <?php
        echo '<p style="padding-top:5pt">Stai recensendo il prodotto "'.$prodotto['Titolo'].'".</p>
              <h4 style="margin-top:10pt; margin-bottom:-10pt">RICORDA!</h4>
              <p>La tua recensione peserà sulla valutazione del venditore "'.$prodotto['Nickname'].'", raccontaci la tua esperienza di acquisto con il nostro utente.</p>';
        ?>
              <table style="margin-top:30pt">
                  <td><label for="titolo">Titolo: </label></td>
                  <td><input type="text" id="titolo" name="titolo" maxlength="30" required></td>
                </tr>
                <tr>
                  <td><label for="titolo">Voto: </label></td>
                  <td>
                    <?php
                        for($i=1;$i<=10;$i++)
                            echo '<input type="radio" name="voto" value="'.$i.'" required>';
                    ?>

                  </td>
                </tr>
                <tr>
                  <td><label for="password">Commento: </label></td>
                  <td><textarea name="commento" rows="15" cols="75" style="resize:none"></textarea></td>
                </tr>
            </table>
            <input type="submit" value="Invia recensione" style="margin-top:10pt  ">
          </form>
        </fieldset>
    </body>
<html>
