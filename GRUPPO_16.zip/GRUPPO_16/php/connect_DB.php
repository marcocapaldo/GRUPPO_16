<?php

$config = parse_ini_file('../cfg/conn.ini', true);

$localhost = $config['database']['localhost'];
$user = $config['database']['user'];
$password = $config['database']['password']; 
$db_name = $config['database']['DBname'];

$connection = mysqli_connect($localhost, $user, $password)
    or die("Connessione fallita!");
                    
mysqli_select_db($connection, $db_name)
    or die("Connessione al DB fallita!");
?>
