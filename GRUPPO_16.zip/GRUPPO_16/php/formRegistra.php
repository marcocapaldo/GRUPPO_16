<?php
session_start();

//se l'utente non ha effettuato il login non avrà l'attributo amministratore settato
if(!isset($_SESSION['amministratore']))
  $_SESSION['amministratore'] = 0;
?>

<html lang="it">
    <head>
        <title>Registrazione</title>
        <link rel="icon" href="../favicon.png">
        <meta name="application name" content="UniBay"/>
        <meta name="author" content="co-authored by Marco Capaldo, Emilio Rago, Andrea Murino">
        <meta name="description" content="Simply eCommerce site based on HTML5, CSS, PHP, JS">
        <meta name="keywords" content="ecommerce, buy, sell, sale, sconti, sconto, smartphone, elettronica">  
        <link href="../css/homeStyle.css" rel="stylesheet" type="text/css">
        <link href="../css/formStyle.css" rel="stylesheet" type="text/css">
        <script type="text/javascript" src="../js/nascondi.js"></script>
        <script type="text/javascript">
          function verificaPassword() {
            if(document.getElementById("password").value == document.getElementById("repassword").value)
              return true;
            else {
              document.getElementById("repassword").value="";
              document.getElementById("repasswordError").innerHTML='Le password non coincidono!';
              return false;
            }
          }
          
          /* Questa è la funzione che garantisce che il primo carattere del nickname non sia un numero */
          function firstCharacter(){
            var c = document.getElementById("nickname").value.charAt(0);      
              if (!isNaN(parseInt(c, 10))) {                                  // Fa il parse in formato decimale
                document.getElementById("nickname").value = "";               // Se il primo carattere è una cifra allora ripristina il campo.
              }               
          }
          
          /* Questa è la funzione che controlla il corretto formato della password inserita dall'utente */
          function passwordCheck(){
            var c = document.getElementById("password").value;
            //(?!.*[\s])(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$^+=!*()@%&]).{8,}
            var pattern = /^[\w]{8,}$/g;   // No blank space, minuscola, maiuscola, numero, carattere speciale, almeno 8 caratteri.
            
            if(!pattern.test(c)){
              document.getElementById("password").value = "";
              alert("La password deve contenere:\nAlmeno 8 caratteri;\nAlmeno 1 carattere maiuscolo;\nAlmeno 1 carattere minuscolo;\nAlmeno un numero;\nAlmeno un carattere speciale;\nNon sono consentiti spazi bianchi");
            }
          }
        </script>
        
        <style type="text/css">
          input:invalid {
              border-left: 3px solid red;     /* Se il campo non è valido allora applica questo stile */
              background-color: white;
        }
        </style>
    </head>
    <body onload= "nascondi(false,'none');">    <!-- nasconde i form relativi ai dati per venditore -->
      
        <?php include 'home.php'; ?>
        <fieldset>
            <legend>Inserisci i tuoi dati</legend>
            <form autocomplete="off" action="./registra.php" method="post" enctype="application/x-www-form-urlencoded" onsubmit="return verificaPassword();">
                <table>
                  <tr><td><label for="radio">Sei un venditore? </label></td>
                    <td><input id ="radio" type="radio" name="venditore" value="1" onclick="nascondi(true,'');"> Si </input>
                    <input id="radio" type="radio" name="venditore" value="0" checked="checked"  onclick="nascondi(false,'none');"> No </input></td>
                </tr>
                <tr><td><label for="nickname">Nickname: </label></td><td><input onkeyup="firstCharacter();" type="text" id="nickname" name="nickname" maxlength="30" required></td>
                </tr>
                <tr><td><label for="password">Password: </label></td><td><input onblur="passwordCheck();" type="password" id="password" name="password" maxlength="30" required></td>
                </tr>
                <tr><td><label for="repassword">Ripeti password: </label></td><td><input type="password" id="repassword" name="repassword" maxlength="30" required> <span id="repasswordError" style="color:red; font-weight:bold"></span></td>
                </tr>
                <tr><td><label for="e-mail">Email: </label></td><td><input type="email" id="e-mail" name="eMail" required></td>
                </tr>
                <tr><td><label for="descrizione">Descriviti: </label></td><td><textarea id="descrizione" name="descrizione" rows="5" cols="40" maxlength="255"></textarea></td>
                </tr>
                <tbody id="venditore">
                  <tr><td><label for="nome">Nome: </label></td><td><input type="text" class="vend" id="nome" name="nome" maxlength="30"></td>
                  </tr>
                  <tr><td><label for="cognome">Cognome: </label></td><td><input type="text" class="vend" id="cognome" name="cognome" maxlength="30"></td>
                  </tr> <!-- Controllo sulla data di nascita, l'utente deve essere almeno maggiorenne e non ultra centenario-->
                  <tr><td><label for="dataNascita">Data di nascita: </label></td><td><input type="date" max="<?php echo (date(Y)-18)."-".date(m)."-".date(d); ?>" min="<?php echo (date(Y)-100)."-".date(m)."-".date(d); ?>" class="vend" id="dataNascita" name="dataNascita"></td>    
                  </tr>
                  <tr><td><label for="indirizzo">Indirizzo: </label></td><td><input type="text" class="vend" id="indirizzo" name="indirizzo" maxlength="50"></td>
                  </tr>
                </tbody>
                <tfoot>
                <tr><td><input type="submit" value="INVIO" class="button" /></td>
                    <td><input type="reset" value="RESET" class="button"/></td>
                </tr>
                </tfoot>
                </table>
            </form>
        </fieldset>
    </body>
</html>
