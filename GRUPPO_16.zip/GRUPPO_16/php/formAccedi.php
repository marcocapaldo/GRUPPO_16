<?php
    session_start();
    require_once 'connect_DB.php';
    
    if(!empty($_POST['nickname']) && !empty($_POST['password'])){
        $addLeft = "a1!@.fg§";   //uso le stringhe usate in fase di registrazione per matchare la password salvata sul db
        $addRight = "A79-i~?Z";
        $cryptPass = $addLeft.$_POST['password'].$addRight;
    
        $query="SELECT * FROM Utente WHERE Nickname='$_POST[nickname]'";
    
        $rs = mysqli_query($connection, $query);
        if(mysqli_num_rows($rs) == 0){
            echo"<script type='text/javascript'>
                    alert('Dati inseriti non validi. Riprova');
                    location.href='./formAccedi.php';
                 </script>";
         }
         else {
            $dati = mysqli_fetch_array($rs);
            if(!password_verify($cryptPass, $dati['Password']))    //controllo se la password data dall'utente matcha con quella salvata sul db
              echo '<script>
                      alert("La password che hai inserito non è corretta. Riprova");
                      location.href="./formAccedi.php";
                    </script>';
    
            $expire = time()+(60*60*24*30);   //il cookie scade dopo 30gg
            setcookie('nickname', $dati['Nickname'], $expire,'/');    //setto un cookie per il nickname e uno per la password dell'utente per farlo accedere rapidamente
            setcookie('password', $_POST['password'], $expire, '/');
            $_SESSION['utente'] = $dati['Nickname'];
            $_SESSION['venditore'] = $dati['Venditore'];
            $_SESSION['amministratore'] = $dati['Amministratore'];
    
            echo "<script>
                      alert('Benvenuto ".$dati['Nickname']."');
                      location.href='./listaProdotti.php';
                  </script>";
         }
    
        mysqli_close($connection);
    }
?>

<?php
if(!isset($_COOKIE['nickname']) OR !isset($_COOKIE['password'])) {
  $nickname = "";
  $password = "";
}
else {
  $nickname = $_COOKIE['nickname'];
  $password = $_COOKIE['password'];
}
?>

<!DOCTYPE html5>
<html lang="it">
    <head>
        <title>Accedi</title>
        <link rel="icon" href="../favicon.png">
        <meta name="application name" content="UniBay"/>
        <meta name="author" content="co-authored by Marco Capaldo, Emilio Rago, Andrea Murino">
        <meta name="description" content="Simply eCommerce site based on HTML5, CSS, PHP, JS">
        <meta name="keywords" content="ecommerce, buy, sell, sale, sconti, sconto, smartphone, elettronica">
        <link href="../css/formStyle.css" rel="stylesheet" type="text/css">
        <link href="../css/homeStyle.css" rel="stylesheet" type="text/css">
        <style type="text/css">
          fieldset{
            width: 300pt;
            height: 200pt;
            position: relative;
            top: 15%;
            left: 30%;
          }
        </style>
    </head>
    <body>
        <?php include 'home.php'; ?>
        <fieldset>
            <legend>Inserisci i tuoi dati</legend>
            <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="application/x-www-form-urlencoded">
                <table id="accedi">
                <tr>
                    <td><label for="nickname">Nickname: </label></td><td><input type="text" id="nickname" name="nickname" value="<?php echo $nickname;?>" maxlength="30" required></td>
                </tr>
                <tr>
                    <td><label for="password">Password: </label></td><td><input type="password" id="password" name="password" value="<?php echo $password;?>" maxlength="10" required></td>
                </tr>
                <tr><td></td>
                    <td><input type="submit" value="INVIO" class="button"/></td>
                </tr>
                </table>
            </form>
            <label> Non hai un account? </label><a href="./formRegistra.php"> Registrati </a>
        </fieldset>

    </body>
</html>
