<html lang="it">
    <head>
        <title>Prodotti</title>
        <link href="../css/boxContainer.css" rel="stylesheet" type="text/css">
        <link href="../css/homeStyle.css" rel="stylesheet" type="text/css">
        <link href="../css/slideShow.css" rel="stylesheet" type="text/css">
    </head>
        
    <body>
	<?php
      require_once 'connect_DB.php';
      require_once 'home.php';

      $codiceProdotto = $_GET['codiceProdotto'];

      //query necessiarie alla visualizzazione della pagina prodotto
        $queryProdotti = "SELECT * FROM Prodotto WHERE Venduto = '0' AND CodiceProdotto = '$codiceProdotto'";
        $queryRecensioni = "SELECT COUNT(*) AS num ,AVG(Voto) as avg FROM Recensione WHERE ID_Recensione IN (SELECT ID_Recensione FROM Proposta
                            WHERE StatoProposta='Accettata' AND CodiceProdotto IN (SELECT CodiceProdotto FROM Prodotto
                            WHERE Venduto = '1' AND Nickname = '";


      //esecuzione query e stampa del risultato
        $prodotto = mysqli_fetch_array(mysqli_query($connection, $queryProdotti));
        $recensioni = mysqli_fetch_array(mysqli_query($connection, $queryRecensioni.$prodotto['Nickname']."'));"));

        $digitalDigitProdotto = strlen(substr(strrchr($prodotto['PrezzoMinimo'], "."), 1));
        $digitalDigitProdotto = ($digitalDigitProdotto == 0) ? ".00":"0";

        echo "<div class='boxExternal'>
                <div class='foto'>";
                $i=0;   //mi carico tutte le foto per il prodotto selezionato ( il loro numero non è fisso )
                $path = "../src/".$prodotto['CodiceProdotto']."[$i].jpg";
                while(file_exists($path)){
                  echo "<img class='slide animate' src='../src/".$prodotto['CodiceProdotto']."[$i].jpg'/>";
                  $i++;
                  $path = "../src/".$prodotto['CodiceProdotto']."[$i].jpg";
                }
                
                if($i>1){//se ho caricato più di una foto faccio partire lo slideShow(vedi file slideShow.js)
                    echo '<script type="text/javascript" src="../js/slideShow.js"></script>';
                }
                else{ 
                    if($i==0) //se non è presente nessuna immagine carico quella di default
                        echo "<img title='Nessuna foto per il prodotto' class='slide animate' src='../src/noImage.jpg'/>";
                    
                    //blocco anche l'animazione
                    echo '<script type="text/javascript"> 
                            document.getElementsByClassName("slide")[0].classList.remove("animate");   
                        </script>';
                }
        echo "</div>
                <section class='details'>
                  <h2>".$prodotto['Titolo']."</h2>
                  <p>".$prodotto['DescrizioneProdotto']."</p>
                  <p>Prezzo: <span>€".$prodotto['PrezzoMinimo'].$digitalDigitProdotto ."</span></p>
                  <p>Data messa in vendita: <span>".$prodotto['DataInVendita']."</span></p>
                  <a href='./dettagliVenditore.php?venditore=".$prodotto['Nickname']."'>".$prodotto['Nickname']." (".$recensioni['num']."
                                     recensioni, ".(float)$recensioni['avg']."/10)</a><br><br>";

        if($prodotto['Venduto'] != '1') {
          if(isset($_SESSION['utente']) && strcmp($_SESSION['utente'], $prodotto['Nickname']) == 0)
            echo "<p>Sei il venditore di questo prodotto, non puoi provare ad acquistarlo.</p>";

          else {

          //recupero l'indirizzo del venditore per mostrarlo in una mappa
          $queryIndirizzoVenditore = "SELECT Indirizzo FROM Utente WHERE Nickname = (SELECT Nickname FROM Prodotto WHERE CodiceProdotto = '".$codiceProdotto."')";
          $indirizzoVenditore = mysqli_fetch_array(mysqli_query($connection, $queryIndirizzoVenditore));

            echo "<form action='./proposta.php?codiceProdotto=".$codiceProdotto."' method='post' autocomplete='off' style='margin-top:10pt'>
                      <label for='importo'>Prezzo: </label>
                      <input type='number' step='0.1' required='true' name='importo' id='importo' min='0'>
                      <input type='submit' value='Fai una proposta!'>
                  </form>
                   <iframe id='map' src='https://www.google.com/maps/embed/v1/place?key=AIzaSyDaZSknmxl6l4dZT5h43NYpQCx6vE0oAqw&q=".$indirizzoVenditore[0]."&zoom=11' allowfullscreen></iframe>
                  <br><input type='button' id='setVisible' value='Nascondi mappa' style='width:110pt; text-align:center'>";
            }
        }
         else {
           echo "<p>Ci dispiace, il prodotto è stato già acquistato...</p>";
         }

      echo '</section>
        <div>';

      mysqli_close($connection);
    ?>

        <script>
        //associo la funzione anonima per nascondere la mappa(con visibility) all'evento click
        document.getElementById("setVisible").onclick = 
        function() {
            var map = document.getElementById("map");
            if(map.style.visibility=="hidden") {
                this.value = "Nascondi mappa";
                map.style.visibility="visible";
            }
            else {
                this.value = "Mostra mappa";
                map.style.visibility="hidden";
            }
        };
        </script>

    </body>
</html>
