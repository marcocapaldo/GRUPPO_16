<html>
  <head>
    <title>Registrazione</title>
    <link rel="icon" href="../favicon.png">
  </head>
  
<?php
session_start();
require_once 'connect_DB.php';

//controllo se la richiesta di registrazione proviene dal form per l'utente o dal pannello admin
if(!isset($_SESSION['amministratore']))
    $_SESSION['amministratore']=0;

extract($_POST);

$addLeft = "a1!@.fg§";   //stringhe casuali da aggiungere prima e dopo la password inserita dall'utente
$addRight = "A79-i~?Z";  //saranno usate le stesse stringhe anche in fase di login per matchare la password salvata sul db
$password = $addLeft.$password.$addRight;
$cryptPass = password_hash($password, PASSWORD_BCRYPT);  //crittografo la password dell'utente tramite una funzione hash

$checkUtenteDuplicato = "SELECT COUNT(*) FROM Utente WHERE Nickname = '".$nickname."'";


if($venditore == 0)
  $queryAddUtente = "INSERT INTO Utente(Nickname,Password,E_Mail,DescrizioneUtente,Venditore, Amministratore)
                     VALUES('$nickname','$cryptPass','$eMail','$descrizione','$venditore','".$_SESSION['amministratore']."')";
else 
  $queryAddUtente = "INSERT INTO Utente(Nickname,Password,E_Mail,DescrizioneUtente,Venditore, Amministratore, Nome, Cognome, DataNascita, Indirizzo)
                     VALUES('$nickname','$cryptPass','$eMail','$descrizione','$venditore','".$_SESSION['amministratore']."','$nome','$cognome','$dataNascita','$indirizzo')";
                     
$isDuplicato = mysqli_fetch_array(mysqli_query($connection,$checkUtenteDuplicato));

if($isDuplicato[0] == 1) {    //controllo se esiste un utente con lo stesso Nickname
  echo "<script>
          alert('Ci dispiace, il nome utente è già in uso. Riprova con un altro Nickname');
          window.history.back();
        </script>";
}
else {
  mysqli_query($connection, $queryAddUtente) or die(mysql_error());
  echo "<script type='text/javascript'>
          alert('Registrazione avvenuta con successo!');
          window.location.href='./listaProdotti.php';
        </script>";

  mysqli_close($connection);
}
?>

</html>
