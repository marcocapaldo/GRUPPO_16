<html>
  <head>
    <title>Effettua una proposta</title>
    <link rel="icon" href="../favicon.png">
  </head>
  <body>

<?php
session_start();
require_once 'connect_DB.php';

if(!isset($_SESSION['utente'])) {
  echo "<script type='text/javascript'>
          alert('Bisogna aver effettuato il login per effettuare una proposta!');
          window.location.href='./formAccedi.php';
        </script>";
}


$nickname = $_SESSION['utente'];
$codiceProdotto = $_GET['codiceProdotto'];
$importo = $_POST['importo'];

$queryNicknameVenditore = "SELECT Nickname FROM Prodotto WHERE CodiceProdotto = '".$codiceProdotto."'";
$nicknameVenditore = mysqli_fetch_array(mysqli_query($connection, $queryNicknameVenditore));

//controllo se il venditore e l'utente che fa l'offerta sono la stessa persona
if(strcmp($nickname, $nicknameVenditore[0]) == 0) {
  echo '<script>
          alert("Non puoi fare proposte per un articolo che hai messo in vendita!");
          location.href = "./listaProdotti.php";
        </script>';
}

$queryAddProposta = "INSERT INTO Proposta (Nickname, CodiceProdotto, Prezzo, DataProposta)
                VALUES ('".$nickname."', '".$codiceProdotto."', '".$importo."', CURRENT_DATE)";

//questa query restituisce il numero di proposte effettuate dallo specifico utente per quel prodotto
$queryNumProposte = "SELECT COUNT(*) AS numProposta FROM Proposta
                  WHERE (CodiceProdotto = '".$codiceProdotto."' AND Nickname = '".$nickname."'
                        AND StatoProposta = 'Inviata')";

$check = mysqli_fetch_row(mysqli_query($connection, $queryNumProposte));

//non consentiremo che un utente faccia più proposte per lo stesso prodotto senza che il venditore le abbia valutate
if($check['0'] >= 1) {
  echo "<script type='text/javascript'>
          alert('Hai già effettuato una proposta che attualmente è in attesa di essere valutata dal venditore.\\n".
                "Riprova quando avrai ricevuto una risposta!');
          window.history.back();
        </script>";
}
else {
  mysqli_query($connection, $queryAddProposta);
  echo "<script type='text/javascript'>
          alert('Ottimo la tua proposta è stata inviata ed è ora in attesa di essere valutata dal venditore.\\n".
                "Riceverai al più presto una risposta, controlla la tua area utente!');
          window.location.href='./profilo.php';
        </script>";
}
?>

  </body>
</html>
