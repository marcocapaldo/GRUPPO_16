<html>
  <head>
    <title>Fai una recensione</title>
    <link rel="icon" href="../favicon.png">
  </head>

<?php
session_start();
require_once 'connect_DB.php';

extract($_POST);
$ID_Proposta = $_GET['idProposta'];

$queryAddRecensione = "INSERT INTO Recensione(TitoloRecensione, Voto, DataRecensione, Commento)
                       VALUES('$titolo', '$voto', CURRENT_DATE, '$commento')";
mysqli_query($connection, $queryAddRecensione) or die("Errore nella query!");

$ID_Recensione = mysqli_insert_id($connection);   //restituisce l'ID_Recensione con cui è stata registrata la Recensione

$queryAddID_Recensione = "UPDATE Proposta SET ID_Recensione = '".$ID_Recensione."' WHERE ID_Proposta = '".$ID_Proposta."'";
mysqli_query($connection, $queryAddID_Recensione) or die("Errore nella query!");   //aggiorno nella tabella Proposta l'ID_Recensione settandolo al valore che ho appena inserito in Recensione

echo '<script>
        alert("La tua recensione è stata correttamente registrata. GRAZIE da parte di tutti i nostri utenti!\nSarai reindirizzato alla tua pagina del profilo.");
        location.href="./profilo.php";
      </script>';
?>

</html>
