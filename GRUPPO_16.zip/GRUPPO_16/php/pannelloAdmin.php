<?php   session_start();

    if(!isset($_SESSION['amministratore']) || $_SESSION['amministratore']==0){
        echo '<script type="text/javascript">
                alert("accedere come amministratore");
                location.href="../php/formAccedi.php";
              </script>';
    }
?>

<html lang="it">
    <head>
        <link href="../css/formStyle.css" rel="stylesheet" type="text/css">
        <link href="../css/boxContainer.css" rel="stylesheet" type="text/css">
        <link href="../css/mainStyle.css" rel="stylesheet" type="text/css">
        <link href="../css/homeStyle.css" rel="stylesheet" type="text/css">
        <script type="text/javascript" src="../js/nascondi.js"></script>
    </head>
    
    <body onload= "nascondi(false,'none');">
        <?php
            include 'home.php';
            require_once 'connect_DB.php';
        ?>
        <section class="admin">
            <details>
                <summary>Registra un amministratore</summary>
            <form  autocomplete="off" action="./registra.php" method="post" enctype="application/x-www-form-urlencoded">
                <table>
                    <tr><td><label>E' un venditore? </label></td>
                        <td><input type="radio" name="venditore" value="1" onclick="nascondi(true,'');"> Si </input>
                        <input type="radio" name="venditore" value="0" checked="checked"  onclick="nascondi(false,'none');"> No </input></td>
                    </tr>
                    <tr><td><label for="nickname">Nickname: </label></td><td><input type="text" id="nickname" name="nickname" maxlength="30" required></td>
                    </tr>
                    <tr><td><label for="password">Password: </label></td><td><input type="password" id="password" name="password" maxlength="10" required></td>
                    </tr>
                    <tr><td><label for="e-mail">Email: </label></td><td><input type="email" id="e-mail" name="eMail" required></td>
                    </tr>
                    <tr><td><label for="descrizione">Descrizione: </label></td><td><textarea id="descrizione" name="descrizione" rows="5" cols="40" maxlength="255"></textarea></td>
                    </tr>
                    <tbody id="venditore">
                    <tr><td><label for="nome">Nome: </label></td><td><input type="text" class="vend" id="nome" name="nome" maxlength="30"></td>
                    </tr>
                    <tr><td><label for="cognome">Cognome: </label></td><td><input type="text" class="vend" id="cognome" name="cognome" maxlength="30"></td>
                    </tr>
                    <tr><td><label for="dataNascita">Data di nascita: </label></td><td><input type="date" data-date-format="DD MMMM YYYY" class="vend" id="dataNascita" name="dataNascita"></td>
                    </tr>
                    <tr><td><label for="indirizzo">Indirizzo: </label></td><td><input type="text" class="vend" id="indirizzo" name="indirizzo" maxlength="50"></td>
                    </tr>
                    </tbody>
                    <tfoot>
                    <tr><td><input type="submit" value="INVIO" class="button" /></td>
                        <td><input type="reset" value="RESET" class="button"/></td>
                    </tr>
                    </tfoot>
                </table>
            </form>
            </details>
        </section>
        
        <section class="admin">
            <details id="modificaCategoria">
                <summary>Modifica categoria</summary>
                <form action="./modificheAdmin.php" method="post">
                <table>
                    <tr>
                        <td><label for="oldCategoria"> Scegli la categoria </label></td>
                        <td><select id="oldCategoria" name="oldNameCategoria" onchange="setDescription(this, 'newDescrizioneCategoria');" required>
                                <option style="display:none">
                                <?php            
                                    $query = "SELECT * FROM Categoria"; 
                                    $rs = mysqli_query($connection, $query) or die("caricamento categorie falllito");
                                    
                                    while($riga = mysqli_fetch_row($rs)) 
                                      echo "<option id='$riga[0]' value='$riga[0]' data-descrizione='$riga[1]'>".$riga[0]."</option>";
                                 ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label for="newCategoria"> Nuovo nome </label></td>
                        <td><input type="text" id="newCategoria" name="newNameCategoria" maxlength="30" required></td>
                    </tr> 
                    <tr>
                        <td><label for="newDescrizioneCategoria"> Descrizione </label></td>
                        <td><textarea id="newDescrizioneCategoria" name="newDescriptionCategoria" rows="5" cols="40" maxlength="255" required></textarea></td>
                    </tr>
                    <tr>
                        <td colspan="2"><input class="button" type="submit" value="Modifica"></td>
                    </tr>                    
                </table>
                <input type="hidden" name="action" value="modificaCategoria" />
                </form>
            </details>
        </section>
       
        <section class="admin">
            <details id="aggiungiCategoria">
                <summary>Aggiungi categoria</summary>
                <form action="./modificheAdmin.php" method="post">
                <table>
                    <tr>
                        <td><label for="addCategoria"> Nome categoria </label></td>
                        <td><input type="text" id="addCategoria" name="addNameCategoria" maxlength="30" required></td>
                    </tr> 
                    <tr>
                        <td><label for="addDescrizioneCategoria"> Descrizione </label></td>
                        <td><textarea id="addDescrizioneCategoria" name="addDescriptionCategoria" rows="5" cols="40" maxlength="255" required></textarea></td>
                    </tr>
                    <tr>
                        <td colspan="2"><input class="button" type="submit" value="Aggiungi"></td>
                    </tr>                    
                </table>
                <input type="hidden" name="action" value="aggiungiCategoria" />
                </form>
            </details>
        </section>
        
        <section class="admin">
            <details id="rimuoviCategoria">
                <summary>Rimuovi categoria</summary>
                <form action="./modificheAdmin.php" method="post">
                <table>
                    <tr>
                        <td><label for="removeCategoria"> Scegli la categoria </label></td>
                        <td><select id="removeCategoria" name="removeNameCategoria" onchange="setDescription(this, 'removeDescrizioneCategoria');" required>
                                <option style="display:none">
                                <?php            
                                    $query = "SELECT * FROM Categoria"; 
                                    $rs = mysqli_query($connection, $query) or die("caricamento categorie falllito");
                                    
                                    while($riga = mysqli_fetch_row($rs)) 
                                      echo "<option id='$riga[0]' value='$riga[0]' data-descrizione='$riga[1]'>".$riga[0]."</option>";
                                 ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label for="removeDescrizioneCategoria"> Descrizione </label></td>
                        <td><textarea id="removeDescrizioneCategoria" rows="5" cols="40" maxlength="255" disabled required ></textarea></td>
                    </tr>
                    <tr>
                        <td colspan="2"><input class="button" type="submit" value="Rimuovi"></td>
                    </tr>                    
                </table>
                <input type="hidden" name="action" value="rimuoviCategoria" />
                </form>
            </details>
        </section>
        
        <section class="admin">
            <details id="rimuoviRecensione">
                <summary>Rimuovi recensione</summary>
                <form action="./modificheAdmin.php" method="post" onsubmit="return checkRecensioni();">
                <?php
                    if(isset($_GET['venditore']) && $_GET['venditore'] != "all"){ //controllo se è stato selezionato un venditore
                        $vend=$_GET['venditore'];
                        $queryVend= " AND Prodotto.Nickname = '$vend'";
                    }
                    else{
                        $vend = 'all';
                        $queryVend = '';
                    }
                        
                    $queryRecensioni = "SELECT Prodotto.Nickname,Recensione.* FROM Recensione,Proposta,Prodotto,Utente WHERE Utente.Nickname = Prodotto.Nickname AND
                                    Prodotto.CodiceProdotto=Proposta.CodiceProdotto AND Proposta.ID_Recensione=Recensione.ID_Recensione AND
                                    Proposta.StatoProposta='Accettata' AND Venditore='1' ".$queryVend;
                    $queryVenditori ="SELECT * FROM Utente WHERE Venditore='1'";
                    $recensioni = mysqli_query($connection, $queryRecensioni) or die("Caricamento recensioni falllito");
                    $venditori = mysqli_query($connection, $queryVenditori) or die("Caricamento venditori per le recensioni falllito");
                ?>

                    <label for="removeRecensioneVenditore"> Scegli il venditore </label>
                    <select id="removeRecensioneVenditore" name="removeRecensioneNickname" onchange="setValueRecensione(this);">
                            <option value="all"> Tutti i venditori </option>
                            <?php            
                                while($riga = mysqli_fetch_array($venditori)) 
                                  echo "<option value='".$riga['Nickname']."'>".$riga['Nickname']."</option>";
                             
                    echo '</select>';          
                    if(mysqli_num_rows($recensioni)!=0){
                        echo '<p>Seleziona le recensioni da eliminare</p>';
                        
                            while($rsRecensioni = mysqli_fetch_array($recensioni)) {			
                                echo "<div class='boxExternal'> 
                                    <section class=''details'>
                                     <h4>".$rsRecensioni['TitoloRecensione']."<br>
                                    <span> Valutazione: </span>".$rsRecensioni['Voto']."/10&emsp;".$rsRecensioni['DataRecensione']."<br>
                                    <span> Commento: </span>".$rsRecensioni['Commento']."</h4>
                                    </section>
                                    <input class='boxRecensioni' type='checkbox' name='removeIdRecensione[]' value='".$rsRecensioni['ID_Recensione']."' />
                                </div>";
                            }
                         echo '<input class="button" type="submit" value="Rimuovi selezionati" on style="position:relative; left:65%; width: auto;">';
                    }
                    else
                        echo '<p>Non sono presenti recensioni</p>';
                ?>
                
                                   
                <input type="hidden" name="action" value="rimuoviRecensione" />
                </form>
            </details>
            <?php
                if(isset($_GET['venditore'])){  //selezione del venditore in rimuoviRecensione
                   echo '<script type="text/javascript">
                       document.getElementById("rimuoviRecensione").open = true;
                       document.getElementById("removeRecensioneVenditore").value = "'.$vend.'";
                       </script>';
                }
            ?>
        </section>
      
        <section class="admin">
            <details id="rimuoviUtente">
                <summary>Rimuovi utente</summary>
                <form action="./modificheAdmin.php" method="post">
                <table>
                    <tr>
                        <td><label for="removeNickname"> Scegli il nickname </label></td>
                        <td><select id="removeNickname" name="removeNickname" onchange="setValueUtente(this);" required>
                                <option style="display:none">
                                <?php         
                                    $query = "SELECT * FROM Utente"; 
                                    $rs = mysqli_query($connection, $query) or die("caricamento utenti falllito");
                                    
                                    while($riga = mysqli_fetch_row($rs)) 
                                      echo "<option id='$riga[0]' value='$riga[0]' data-vend='$riga[8]' data-e_mail='$riga[2]' data-descrizione='$riga[3]' >".$riga[0]."</option>";
                                 ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label> Venditore </label></td>
                        <td><input id ="radioVendSi" type="radio" disabled > Si </input>
                        <input id="radioVendNo" type="radio" disabled > No </input></td>
                    </tr>
                    <tr><td><label for="removeE-mail">Email: </label></td><td><input type="email" id="removeE-mail" disabled required></td>
                    </tr>
                    <tr><td><label for="removeDesc">Descrizione: </label></td><td><textarea id="removeDesc" rows="5" cols="40" maxlength="255" disabled required></textarea></td>
                    </tr>
                    <tr>
                        <td colspan="2"><input class="button" type="submit" value="Rimuovi"></td>
                    </tr>                    
                </table>
                <input type="hidden" name="action" value="rimuoviUtente" />
                </form>
            </details>
        </section>
        
<?php
     if(!empty($_GET['action'])){
         echo '<script type="text/javascript">
                 document.getElementById("'.$_GET['action'].'").open = true;
                </script>';
     } 
 ?>
    </body>
</html>