<?php
    if(!empty($_GET['venditore']))
        $venditore = $_GET['venditore'];
    else
        header('Location: ./listaProdotti.php');
?>

<!DOCTYPE html5>
<html lang="it">
    <head>
        <title>Profilo venditore</title>
        <link rel="stylesheet" type="text/css" href="../css/boxContainer.css">
        <link rel="stylesheet" type="text/css" href="../css/homeStyle.css">
    </head>
    <body>
    <?php
        include 'home.php';
        require_once 'connect_DB.php';

        $queryVenditore = "SELECT * FROM Utente WHERE Nickname = '".$venditore."'";
        $queryRecensioni = "SELECT * FROM Recensione WHERE ID_Recensione IN (SELECT ID_Recensione FROM Proposta
                            WHERE StatoProposta='Accettata' AND CodiceProdotto IN (SELECT CodiceProdotto FROM Prodotto
                            WHERE Venduto = '1' AND Nickname = '".$venditore."'));";
        $queryMediaRecensioni = "SELECT COUNT(*) AS Num , coalesce(AVG(Voto),0) as Avg FROM Recensione WHERE ID_Recensione IN (SELECT ID_Recensione FROM Proposta
                                 WHERE StatoProposta='Accettata' AND CodiceProdotto IN (SELECT CodiceProdotto FROM Prodotto
                                 WHERE Venduto = '1' AND Nickname = '".$venditore."'))";

        //acquisisco le informazioni del venditore dal db
        $rsVenditore = mysqli_fetch_array(mysqli_query($connection, $queryVenditore));
        $mediaRecensioni = mysqli_fetch_array(mysqli_query($connection, $queryMediaRecensioni));

        echo "<div class='boxExternal' style='border:0px'>
                <section class='foto'>
                    <img id='prodotto' src='../src/user.jpg' width='300pt'>
                </section>
                <section class='details'>
                    <table>
                        <thead><h1>Informazioni venditore </h1></thead>
                        <tr><td> Nome utente: </td><td><span>".$rsVenditore['Nickname']."</span></td></tr>
                        <tr><td> Nominativo: </td><td><span>".$rsVenditore['Nome']." ".$rsVenditore['Cognome']."</span></td></tr>
                        <tr><td> Descizione: </td><td><span>".$rsVenditore['DescrizioneUtente']."</span></td></tr>
                        <tr><td> Info e contatti: </td><td><span>".$rsVenditore['E_Mail']."</span></td></tr>
                    </table>";

          if($mediaRecensioni['Num'] != 0) {
            echo '<br><table>
                    <tr>
                      <td><img width="75pt" height="75pt" src="../src/bestSeller.png"></td>
                      <td><a>'.(float)$mediaRecensioni['Avg'].'/10 ('.$mediaRecensioni['Num'].' recensioni)</a></td>
                    </tr>
                  </table>';
          }
          else {
            echo '<br><br><p>Nessuna recensione per questo venditore.</p>';
          }

          echo "</section>
              </div>";

        $res = mysqli_query($connection, $queryRecensioni);

        while($rsRecensioni = mysqli_fetch_array($res)) {
            echo "<div class='boxExternal'>
                    <section class=''details'>
                        <h4>".$rsRecensioni['TitoloRecensione']."<br>
                        <span> Valutazione: </span>".$rsRecensioni['Voto']."/10&emsp;".$rsRecensioni['DataRecensione']."<br>
                        <span> Commento: </span>".$rsRecensioni['Commento']."</h4>
                    </section>
                  </div>";
        }
    ?>
    </body>
</html>
