<html>
  <head>
    <title>Aggiungi prodotto</title>
    <link rel="icon" href="../favicon.png">
  </head>

<?php
session_start();
require_once 'connect_DB.php';

extract($_POST);

$queryAddProdotto = "INSERT INTO Prodotto(Nickname,TitoloCategoria,Titolo,DescrizioneProdotto,DataInVendita,PrezzoMinimo)
                     VALUES ('$_SESSION[utente]','$TitoloCategoria','$titolo','$descrizione',CURRENT_DATE,$prezzo)";

if(empty($_FILES) OR $_FILES['fotoProdotto'].count==0){
 //inserisco il prodotto nel DB
  mysqli_query($connection, $queryAddProdotto) or die("ERRORE");
}
else {

  foreach ($_FILES['fotoProdotto']['size'] as $filesize) {
    if($filesize > 10000000)
      echo '<script>
              alert("Dimensione del file troppo grande. Ripovare");
              location.href="./formProdotto.php";
            </script>';
    //N.B Non controllo l'estenzione del file perchè in formProdotto.php ho già richiesto l'accettazione di sole immagini
  }
  
  //inserisco il prodotto nel DB
  mysqli_query($connection, $queryAddProdotto) or die("ERRORE");
  $codProdotto = mysqli_insert_id($connection);     //restituisce il codice prodotto con cui è stato registato l'oggetto

  $i=0;//questo sarà l'indice per memorizzare più immagini relative allo stesso prodotto
  foreach ($_FILES['fotoProdotto']['name'] as $filename) {
    
    //N.B Il nome delle immagini è dato dal codice prodotto così da renderlo univoco e identificabile
    $newPath = "../src/".$codProdotto."[$i].jpg";
  
    if(file_exists($newPath)){
      echo '<script>
              alert("Il prodotto è stato registato ma qualcosa è andato storto durante il caricamento dell\'immagine.");
            </script>';
    }
    if(!move_uploaded_file($_FILES['fotoProdotto']['tmp_name'][$i], $newPath)) {
      echo '<script>
              alert("ERRORE SPOSTAMENTO: '.$newPath.'")</script>';
    }
     
    $i++;
  }
}

echo"<script type='text/javascript'>
        alert('Prodotto pubblicato');
        location.href='./listaProdotti.php';
      </script>";

mysqli_close($connection);
?>

</html>
