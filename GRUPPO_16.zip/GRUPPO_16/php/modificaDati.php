<html>
  <head>
    <title>Modifica dati</title>
    <link rel="icon" href="../favicon.png">
  </head>

<?php
session_start();
require_once 'connect_DB.php';

//Se l'utente sceglie di cambiare i dati personali modifica=1, se reimposta la password modifica=2
$modifica = $_GET['azione'];
extract($_POST);

if($modifica == '1') {
  if($venditore == 0)
    $queryModificaDati = "UPDATE Utente SET Venditore = '".$venditore."', E_Mail = '".$eMail."', DescrizioneUtente = '".$descrizione."'
                          WHERE Nickname = '".$_SESSION['utente']."'";
  else
    $queryModificaDati = "UPDATE Utente SET Venditore = '".$venditore."', E_Mail = '".$eMail."', DescrizioneUtente = '".$descrizione."',
                                            Nome = '".$nome."', Cognome = '".$cognome."', DataNascita = '".$dataNascita."', Indirizzo = '".$indirizzo."'
                          WHERE Nickname = '".$_SESSION['utente']."'";

  $result = mysqli_query($connection, $queryModificaDati) or die("Errore query!");
}

else {
  $addLeft = "a1!@.fg§";   //stringhe casuali da aggiungere prima e dopo la password inserita dall'utente
  $addRight = "A79-i~?Z";
  $oldpassword = $addLeft.$oldpassword.$addRight;

  $queryPassUtente = "SELECT Password FROM Utente WHERE Nickname = '".$_SESSION['utente']."'";
  $password = mysqli_fetch_array(mysqli_query($connection, $queryPassUtente))['Password'];

  //Controllo se la password salvata nel db corrisponda a quella digitata e che quelle digitate per sostituirla corrispondano
  if(!password_verify($oldpassword, $password))
    echo '<script>
            alert("La password che hai inserito non è corretta. Riprova");
            location.href="./profilo.php";
          </script>';

  if(strcmp($newpassword,$repassword) != 0)
    echo '<script>
            alert("Le password non corrispondono. Fai attenzione!");
            location.href="./profilo.php";
          </script>';

  if(strcmp($newpassword,$oldpassword) == 0)
    echo '<script>
            alert("La nuova e la vecchia password non possono essere uguali!");
            location.href="./profilo.php";
          </script>';

  $newpassword = $addLeft.$newpassword.$addRight;
  $cryptPass = password_hash($newpassword, PASSWORD_BCRYPT);  //crittografo la password dell'utente tramite una funzione hash

  $queryModificaPass = "UPDATE Utente SET Password = '".$cryptPass."' WHERE Nickname = '".$_SESSION['utente']."'";
  $result = mysqli_query($connection, $queryModificaPass) or die("Errore query!");
}

echo "<script>
          var expires = new Date();
          expires.setMonth(expires.getMonth()+1);
           
          var cookie = 'password='+'".$newpassword."'+'; expires='+expires+';';
          document.cookie = cookie;
          alert('Modifica avvenuta con successo! Le tue nuove informazioni sono state registrate.');
          window.history.back();
      </script>";
?>

</html>
