<html>
  <head>
    <title>Cambia stato proposta</title>
    <link rel="icon" href="../favicon.png">
  </head>
  <body>

<?php
require_once 'connect_DB.php';

$codiceProdotto = $_GET['codiceProdotto'];
$idProposta = $_GET['idProposta'];
$statoProposta = $_GET['select']; //contiene la l'indice della selezione fatta nel profilo utente (1=accettata, 2=rifiutata)

if($statoProposta == '1') {
  $queryCambiaStato = "UPDATE Proposta SET StatoProposta = 'Accettata', DataAccettata = CURRENT_DATE WHERE ID_Proposta = '".$idProposta."'";
  $queryRifiutaAuto = "UPDATE Proposta SET StatoProposta = 'Rifiutata' WHERE CodiceProdotto = '".$codiceProdotto."'";
  $querySetProdottoVenduto = "UPDATE Prodotto SET Venduto = 1 WHERE CodiceProdotto = '".$codiceProdotto."'";
  $result = mysqli_query($connection, $querySetProdottoVenduto); //setto come venduto il prodotto per cui si è accettati la proposta
  $result = mysqli_query($connection, $queryRifiutaAuto); //se il venditore ha accettato una proposta per un certo articolo, automaticamente rifiuta le altre
}
else
  $queryCambiaStato = "UPDATE Proposta SET StatoProposta = 'Rifiutata' WHERE ID_Proposta = '".$idProposta."'";

$result = mysqli_query($connection, $queryCambiaStato) or die("Errore query!");
echo "<script>window.history.back()</script>";
?>

  </body>
</html>
