<html>
  <head>
    <title>Elimina prodotto</title>
    <link rel="icon" href="../favicon.png">
  </head>
  <body>

<?php
require_once 'connect_DB.php';

$codiceProdotto = $_GET['codiceProdotto'];

$queryEliminaProdotto = "DELETE FROM Prodotto WHERE CodiceProdotto = '".$codiceProdotto."'";
$eliminaProdotto = mysqli_query($connection, $queryEliminaProdotto) or die("Problemi nell'eseguire la query");

echo '<script>
        alert("L\'annuncio è stato rimosso con successo.");
        window.history.back();
      </script>';
?>

  </body>
</html>
