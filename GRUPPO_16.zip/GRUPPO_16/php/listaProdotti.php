<?php
    if(!empty($_GET['logout'])){
        session_start();
        session_destroy();
        echo "<script type='text/javascript'>
            alert('Logout effettuato. Torna a trovarci presto!');
            location.href='../php/listaProdotti.php'
          </script>";
    }
?>
<html lang="it">
    <head>
        <link href="../css/tableStyle.css" rel="stylesheet" type="text/css">
        <link href="../css/boxContainer.css" rel="stylesheet" type="text/css">
        <link href="../css/mainStyle.css" rel="stylesheet" type="text/css">
        <link href="../css/homeStyle.css" rel="stylesheet" type="text/css">
        <script type="text/javascript" src="../js/prodotti.js"></script>
    </head>

    <body>
        <?php

         //controllo i campi che sono passati nel filtro di ricerca
         if(!empty($_GET['cercaTitolo'])){
           $titolo = $_GET['cercaTitolo'];
           $queryTit = " AND Titolo LIKE '%$titolo%' ";
         } else {
            $titolo=$queryTit='';
         }
         if(!empty($_GET['prezzo_min']) && is_numeric($_GET['prezzo_min'])){
           $min = $_GET['prezzo_min'];
           $queryMin = " AND PrezzoMinimo > '$min' ";
         } else {
            $min=$queryMin='';
         }
         if(!empty($_GET['prezzo_max']) && is_numeric($_GET['prezzo_max'])){
           $max = $_GET['prezzo_max'];
           $queryMax = " AND PrezzoMinimo < '$max' ";
         } else {
            $max=$queryMax='';
         }
         if(!empty($_GET['dataPubblicato'])){
           $data = $_GET['dataPubblicato'];
           $queryData = " AND DataInVendita >= '$data' ";
         } else {
            $data=$queryData='';
         }
         if(!empty($_GET['categoria'])){
           $cat = $_GET['categoria'];
           $queryCategoria = " AND TitoloCategoria = '$cat' ";
         } else {
            $cat=$queryCategoria='';
         }
         if(!empty($_GET['venditore'])){
           $vend = $_GET['venditore'];
           $queryVend = " AND Prodotto.Nickname LIKE '$vend' ";
         } else {
            $vend=$queryVend='';
         }
         if(!empty($_GET['ordine'])){
           $ord = $_GET['ordine'];
           $queryOrdine = " ORDER BY $ord ";
         } else {
            $ord=$queryOrdine='';
         }

         require_once 'connect_DB.php';
         include 'home.php';
        ?>

        <nav>
            <form id="formFiltro" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
            <div class="table" style="width: 100%">
            <div class="tableRow">
                <div class="tableCell">
                    <label for="prezzomin" > Prezzo minimo </label>
                </div>
                <div class="tableCell">
                    <label for="prezzomax" > Prezzo massimo </label>
                </div>
                <div class="tableCell">
                    <label for="data"> In vendita dal </label>
                </div>
                <div class="tableCell">
                    <label for="venditore"> Venditore </label>
                </div>
                <div class="tableCell">
                     <label for="order" > Ordina per </label>
                </div>
                <div class="tableCell">
                    <input type="submit" value="Azzera filtri" onclick="resetta();" style="width: 100pt"/>
                </div>
            </div> 
            <div class="tableRow">
                <div class="tableCell">
                    <input class='filtro' type='number' id='prezzomin' step='0.1' name='prezzo_min' min='1' value='<?php echo $min; ?>'>
                </div>
                <div class="tableCell">
                    <input class='filtro' type='number' id='prezzomax' step='0.1' name='prezzo_max' min='1' value='<?php echo $max; ?>'>
                </div>
                <div class="tableCell">
                    <input class='filtro' type='date' id='data' name='dataPubblicato' value='<?php echo $data; ?>'>
                </div>
                <div class="tableCell">
                    <select id="IDvenditore" class="filtro" name="venditore">
                    <?php
                        require_once 'connect_DB.php';

                        $query = "SELECT * FROM Utente WHERE Venditore='1'";
                        $rs = mysqli_query($connection, $query) or die("caricamento venditori falllito!");

                        echo "<option value=''></option>";

                        while($riga = mysqli_fetch_row($rs)) {
                            echo "<option value='$riga[0]'>".$riga[0]."</option>";
                        }
                    ?>
                    </select>
                </div>
                <div class="tableCell">
                    <select id="IDordine" class="filtro" name="ordine">
                        <option value=""></option>
                        <option value="Media DESC"> Media recensioni </option>
                        <option value="PrezzoMinimo ASC"> Prezzo crescente </option>
                        <option value="PrezzoMinimo DESC"> Prezzo decrescente </option>
                        <option value="DataInVendita DESC"> Nuovi oggetti </option>
                    </select>
                </div>
                <div class="tableCell">
                    <input type="submit" value="Applica filtro" style="width: 100pt"/>
                </div>
                <!--mi serve per memorizzare il form per cercare nel titolo-->
                <input type="hidden" class="filtro" value="<?php echo $titolo; ?>" name="cercaTitolo">
            </div>
            </div>
            </form>
        </nav>

        <aside>
            <div class="table"div>
            <div class="tableRow">
                <div class="tableCell">
                    <input type="radio" form="formFiltro" name="categoria" id="tutte" value="" onclick="document.getElementById('formFiltro').submit();"> Tutte le categorie </input>
                </div>
            </div>
            <?php
            $query="SELECT TitoloCategoria FROM Categoria";
            $rs = mysqli_query($connection, $query) or die("caricamento categorie fallito");
            while($riga = mysqli_fetch_row($rs)) {
              echo "<div class='tableRow'>
                    <div class='tableCell'>
                        <input form='formFiltro' type='radio' name='categoria' id='$riga[0]' value='$riga[0]'
                             onclick='document.getElementById(\"formFiltro\").submit();'> $riga[0] </input>
                    </div>
                    </div>";
            }
            
            echo "<script type='text/javascript'> //imposto i valori selezionati nei filtri
                    checkRadioCategoria('$cat');  
                    checkSelectVenditore('$vend');
                    checkSelectOrder('$ord');
            </script>";
            ?>
            </div>
        </aside>

        <div id="main">
            <?php
             $queryProdotti = "SELECT Prodotto.*, Media, coalesce(MediaRecensioni.Num,0) as Num FROM Prodotto LEFT JOIN MediaRecensioni ON Prodotto.Nickname=MediaRecensioni.Nickname
                                WHERE Venduto='0'"."$queryTit"."$queryMin"."$queryMax"."$queryData"."$queryCategoria"."$queryVend"."$queryOrdine";

             $rs = mysqli_query($connection, $queryProdotti);

             if(mysqli_num_rows($rs) != 0) {
                 while($result = mysqli_fetch_array($rs)) { 
                    
                   //faccio comparire i centesimi nel prezzo (potrebbero non esserci se sono 0) 
                   $digitalDigitProdotto = strlen(substr(strrchr($result['PrezzoMinimo'], "."), 1));
                   $digitalDigitProdotto = ($digitalDigitProdotto == 0) ? ".00":"0";

                   $path = "../src/".$result['CodiceProdotto']."[0].jpg"; //path foto prodotto
                   if(!file_exists($path))  //se non è presente nessuna immagine carico quella di default
                     $path = "../src/noImage.png' title='Nessuna foto per il prodotto";
                   
                   //box con il prodotto
                   echo "<div class='boxExternal'>
                           <section class='foto'>
                                <a href='./prodotto.php?codiceProdotto=".$result['CodiceProdotto']."'><img src='$path'></a>
                           </section>
                           <section class='details'>
                             <strong style='font-size:20pt'><a href='./prodotto.php?codiceProdotto=".$result['CodiceProdotto']."'>".$result['Titolo']."</a></strong>
                             <p>Prezzo: <span>€".$result['PrezzoMinimo'].$digitalDigitProdotto."</span></p>
                             <a href='./dettagliVenditore.php?venditore=".$result['Nickname']."'>".$result['Nickname']." ( ".$result['Num']."
                                 recensioni, ".(float)$result['Media']."/10)</a>
                             <p>Pubblicato il: ".date('d/m/Y', strtotime($result['DataInVendita']))."
                             <br>Categoria: ".$result['TitoloCategoria']."</p>
                           </section>
                        </div>";
                 }
             }
             else {
                 echo "<p class='noproduct'>Non ci sono prodotti da mostrare!</p>";
             }
             mysqli_free_result($rs);
            ?>
        </div>
    </body>
</html>
