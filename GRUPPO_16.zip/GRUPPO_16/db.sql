
-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Creato il: Mag 16, 2018 alle 11:24
-- Versione del server: 5.7.22-0ubuntu0.17.10.1
-- Versione PHP: 7.1.15-0ubuntu0.17.10.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db`
--
CREATE DATABASE eCommerce;
-- --------------------------------------------------------

--
-- Struttura della tabella `Categoria`
--

CREATE TABLE `Categoria` (
  `TitoloCategoria` varchar(30) NOT NULL,
  `DescrizioneCategoria` char(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `Categoria`
--

INSERT INTO `Categoria` (`TitoloCategoria`, `DescrizioneCategoria`) VALUES
('Abbigliamento', 'abiti, scarpe, borse, cappelli'),
('Gioielli', 'collane, orecchini, anelli e chi ne ha piÃ¹ ne metta'),
('Informatica', 'smartphone, pc, stampanti');

-- --------------------------------------------------------

--
-- Struttura stand-in per le viste `MediaRecensioni`
-- (Vedi sotto per la vista effettiva)
--
CREATE TABLE `MediaRecensioni` (
`Nickname` varchar(30)
,`Num` bigint(21)
,`Media` decimal(14,4)
);

-- --------------------------------------------------------

--
-- Struttura della tabella `Prodotto`
--

CREATE TABLE `Prodotto` (
  `CodiceProdotto` int(11) NOT NULL,
  `Nickname` varchar(30) NOT NULL,
  `TitoloCategoria` varchar(30) NOT NULL,
  `Titolo` varchar(30) NOT NULL,
  `DescrizioneProdotto` varchar(255) NOT NULL,
  `DataInVendita` date NOT NULL,
  `PrezzoMinimo` float NOT NULL,
  `Venduto` smallint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `Prodotto`
--

INSERT INTO `Prodotto` (`CodiceProdotto`, `Nickname`, `TitoloCategoria`, `Titolo`, `DescrizioneProdotto`, `DataInVendita`, `PrezzoMinimo`, `Venduto`) VALUES
(42, 'Venditore', 'Informatica', 'Macbook pro', 'Vendo fantastico laptop a prezzo stracciato', '2018-05-16', 1299, 0),
(43, 'Venditore', 'Gioielli', 'Anello strolli', 'Fantastico anello per fidanzamento', '2018-05-16', 500, 0),
(44, 'Venditore', 'Abbigliamento', 'Giubbino Lacoste', 'Edizione 2018', '2018-05-16', 199, 1),
(47, 'Venditore', 'Informatica', 'Macbook air', 'Vendo il macbook versione povera, accorrete, il prezzo Ã¨ conveniente!', '2018-05-16', 899, 1),
(48, 'Venditore2', 'Gioielli', 'Rolex', 'Vendo il rolex piÃ¹ bello del mondo', '2018-05-16', 9999, 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `Proposta`
--

CREATE TABLE `Proposta` (
  `ID_Proposta` int(11) NOT NULL,
  `Nickname` varchar(30) NOT NULL,
  `CodiceProdotto` int(11) NOT NULL,
  `ID_Recensione` int(11) DEFAULT NULL,
  `Prezzo` float NOT NULL,
  `StatoProposta` enum('Inviata','Rifiutata','Accettata') NOT NULL,
  `DataProposta` date NOT NULL,
  `DataAccettata` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `Proposta`
--

INSERT INTO `Proposta` (`ID_Proposta`, `Nickname`, `CodiceProdotto`, `ID_Recensione`, `Prezzo`, `StatoProposta`, `DataProposta`, `DataAccettata`) VALUES
(1, 'utente', 44, NULL, 200, 'Rifiutata', '2018-05-16', NULL),
(2, 'utente', 44, 3, 250, 'Accettata', '2018-05-16', '2018-05-16'),
(3, 'utente2', 42, NULL, 1400, 'Inviata', '2018-05-16', NULL),
(4, 'utente3', 42, NULL, 1600, 'Inviata', '2018-05-16', NULL),
(5, 'utente3', 47, 4, 900, 'Accettata', '2018-05-16', '2018-05-16'),
(6, 'utente', 48, NULL, 10500, 'Inviata', '2018-05-16', NULL);

-- --------------------------------------------------------

--
-- Struttura della tabella `Recensione`
--

CREATE TABLE `Recensione` (
  `ID_Recensione` int(11) NOT NULL,
  `TitoloRecensione` varchar(30) NOT NULL,
  `Voto` int(11) NOT NULL,
  `DataRecensione` date NOT NULL,
  `Commento` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `Recensione`
--

INSERT INTO `Recensione` (`ID_Recensione`, `TitoloRecensione`, `Voto`, `DataRecensione`, `Commento`) VALUES
(3, 'Pessimo venditore', 2, '2018-05-16', 'Ho acquistato questo prodotto ma sono stato truffato dal venditore!!!'),
(4, 'Ottimo venditore', 8, '2018-05-16', 'Ho acquistato questo splendido Macbook Air, il venditore si Ã¨ dimostrato serio e cordiale, davvero consigliato');

-- --------------------------------------------------------

--
-- Struttura della tabella `Utente`
--

CREATE TABLE `Utente` (
  `Nickname` varchar(30) NOT NULL,
  `Password` varchar(500) NOT NULL,
  `E_Mail` varchar(50) NOT NULL,
  `DescrizioneUtente` char(255) NOT NULL,
  `Nome` varchar(30) DEFAULT NULL,
  `Cognome` varchar(30) DEFAULT NULL,
  `DataNascita` date DEFAULT NULL,
  `Indirizzo` varchar(30) DEFAULT NULL,
  `Venditore` smallint(1) NOT NULL DEFAULT '0',
  `Amministratore` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `Utente`
--

INSERT INTO `Utente` (`Nickname`, `Password`, `E_Mail`, `DescrizioneUtente`, `Nome`, `Cognome`, `DataNascita`, `Indirizzo`, `Venditore`, `Amministratore`) VALUES
('admin', '$2y$10$jbculU6z8RVW3H2yf77MGuwVAdI1hIOAgd/sXcFeWDJd86RmeVqJy', 'admin@unisa.it', 'Sono un venditore', 'Andrea', 'Murino', '1995-10-17', 'via dei mille 11', 1, 1),
('utente', '$2y$10$hnm6Xw6F.QTmxdAt4VzwquVtrL1akhtVErAafvov3xw8p6mpUyozm', 'utente@unisa.it', 'Sono un normale utente che puÃ² effettuare acquisti', NULL, NULL, NULL, NULL, 0, 0),
('utente2', '$2y$10$/fbM.GpJ89UH00YjFrrqXOvwn05Fb0wCYM4HwDn1snnCzupUuFz2O', 'utente2@unisa.it', 'Sono il secondo utente di questo fantastico sito! Posso soltanto effettuare acquisti', NULL, NULL, NULL, NULL, 0, 0),
('utente3', '$2y$10$31jLLBx1sveuER3geZAuMOSZ/5sHe6jVsl4Y5VYaugyGNTFnZx7za', 'utente3@unisa.it', 'sono il terzo utente', NULL, NULL, NULL, NULL, 0, 0),
('Venditore', '$2y$10$Gjj6tVXui/Llzcw.iPLtMO7.0Y3pCrbss0qwykWDeKpFWcYQvp/7.', 'venditore@unisa.it', 'Sono un venditore', 'Luca', 'Venditore', '1980-04-10', 'via dei venditori', 1, 0),
('Venditore2', '$2y$10$TutBi/BtSNVIwA4hu3FBK.SYl5ZNgsYuL8TypgR8wiPaRcYImJiH2', 'venditore2@unisa.it', 'Sono il secondo venditore del sito', 'venditore', 'figo', '1990-01-10', 'Via delle sequoie', 1, 0);

-- --------------------------------------------------------

--
-- Struttura per la vista `MediaRecensioni`
--
DROP TABLE IF EXISTS `MediaRecensioni`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `MediaRecensioni`  AS  select `Prodotto`.`Nickname` AS `Nickname`,coalesce(count(0),0) AS `Num`,coalesce(avg(`Recensione`.`Voto`),0) AS `Media` from ((`Recensione` join `Proposta`) join `Prodotto`) where ((`Prodotto`.`Venduto` = '1') and (`Proposta`.`StatoProposta` = 'Accettata') and (`Prodotto`.`CodiceProdotto` = `Proposta`.`CodiceProdotto`) and (`Proposta`.`ID_Recensione` = `Recensione`.`ID_Recensione`)) group by `Prodotto`.`Nickname` ;

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `Categoria`
--
ALTER TABLE `Categoria`
  ADD PRIMARY KEY (`TitoloCategoria`);

--
-- Indici per le tabelle `Prodotto`
--
ALTER TABLE `Prodotto`
  ADD PRIMARY KEY (`CodiceProdotto`),
  ADD KEY `FK_PROD_CAT` (`TitoloCategoria`),
  ADD KEY `FK_PROD_UTENTE` (`Nickname`);

--
-- Indici per le tabelle `Proposta`
--
ALTER TABLE `Proposta`
  ADD PRIMARY KEY (`ID_Proposta`),
  ADD KEY `FK_PROP_PROD` (`CodiceProdotto`),
  ADD KEY `FK_PROP_RECENS` (`ID_Recensione`),
  ADD KEY `FK_PROP_UTENTE` (`Nickname`);

--
-- Indici per le tabelle `Recensione`
--
ALTER TABLE `Recensione`
  ADD PRIMARY KEY (`ID_Recensione`);

--
-- Indici per le tabelle `Utente`
--
ALTER TABLE `Utente`
  ADD PRIMARY KEY (`Nickname`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `Prodotto`
--
ALTER TABLE `Prodotto`
  MODIFY `CodiceProdotto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT per la tabella `Proposta`
--
ALTER TABLE `Proposta`
  MODIFY `ID_Proposta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT per la tabella `Recensione`
--
ALTER TABLE `Recensione`
  MODIFY `ID_Recensione` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `Prodotto`
--
ALTER TABLE `Prodotto`
  ADD CONSTRAINT `FK_PROD_CAT` FOREIGN KEY (`TitoloCategoria`) REFERENCES `Categoria` (`TitoloCategoria`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_PROD_UTENTE` FOREIGN KEY (`Nickname`) REFERENCES `Utente` (`Nickname`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `Proposta`
--
ALTER TABLE `Proposta`
  ADD CONSTRAINT `FK_PROP_PROD` FOREIGN KEY (`CodiceProdotto`) REFERENCES `Prodotto` (`CodiceProdotto`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_PROP_RECENS` FOREIGN KEY (`ID_Recensione`) REFERENCES `Recensione` (`ID_Recensione`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_PROP_UTENTE` FOREIGN KEY (`Nickname`) REFERENCES `Utente` (`Nickname`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
